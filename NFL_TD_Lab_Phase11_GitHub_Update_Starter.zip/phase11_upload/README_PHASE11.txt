NFL TD LAB -- PHASE 11 (SAFE GITHUB AUTO-UPDATE PREPARATION)
=============================================================

OUR GOAL
--------
Your GitHub Pages app already works at https://durrgyj222-pixel.github.io/nfl-td-lab/
Phase 11 gives that existing site a GitHub Actions workflow that can rebuild its
public predictions from nflverse + Open-Meteo without leaving your computer on.

IMPORTANT: THIS FIRST WORKFLOW IS MANUAL-TRIGGERED FOR SAFETY.
We will enable timed automation AFTER the first cloud run succeeds.

NO API KEY IS NEEDED. NO PLAYER ODDS. No model probabilities are injury- or
weather-adjusted. All values remain unvalidated research forecasts.

UPLOAD -- DON'T REPLACE THE CURRENT WEBSITE
-------------------------------------------
Extract this ZIP. Open the folder named phase11_upload.
In GitHub go to the Code tab for your nfl-td-lab repository.
Choose Add file -> Upload files.
Drag ALL CONTENTS of phase11_upload into the browser, including:
  .github/workflows/refresh-dashboard.yml
  scripts/refresh_dashboard.py
  phase10_assets/(the 8 asset files)
  td_model.py
  td_weekly.py
  td_backtest.py
  td_phase5.py
  td_phase6.py
  td_phase7_fixed.py
  td_phase8_weather.py
  td_phase9_availability.py
  td_phase10_site.py
  .gitignore
  README_PHASE11.txt
Commit to main. DO NOT DELETE or overwrite docs/ -- it contains your LIVE WEBSITE.
If GitHub web upload does not show the .github folder, STOP and tell ChatGPT.

RUN ON GITHUB (NOT COMMAND PROMPT)
---------------------------------
1. Open your repository -> Actions tab.
2. Click "Refresh NFL TD Lab dashboard" in the left sidebar.
3. Click "Run workflow" -> branch main -> green "Run workflow".
4. Click the new run. Wait until green check or red X.
5. On success, open your existing public website, reload, and check that the
   saved timestamp and game list have updated.
6. If red X, open the failed step and send its error text or screenshot.

WHAT THE WORKFLOW DOES
----------------------
Checks current NFL schedule and current player stats before doing the large
model work. Runs Phase 7, Phase 8 and Phase 9 in order. Verifies upcoming
matchups, plausible player counts and probabilities, then writes docs/data.json
atomically. Commits ONLY docs/data.json. A failed command never commits.
If no upcoming games or if the season's stats aren't ready, it keeps your
working old website; the page still displays its timestamp.

LIMITATIONS
-----------
The current forecast engine was mainly trained using 2024 and reviewed against
2025 repeatedly; that is not a fresh unbiased holdout. Forecasted weather and
injury availability are contextual labels only. Official 90-minute active lists
are not ingested. For iPhone users the installed app fetches the updated JSON
when opened with internet. Refresh Safari if needed.

OFFLINE SELF-TEST IF YOU WANT IT
--------------------------------
Run in a copy of the extracted folder (not on your production site):
   py scripts/refresh_dashboard.py --self-test
It uses fixture data only, does not download anything and does not update docs.

NEXT PHASE
----------
After green Actions run, activate a conservative Thursday/Saturday/Sunday
schedule. Don't enable scheduled runs before checking that permissions and the
live NFL endpoints succeed with a clean GitHub Actions environment.
